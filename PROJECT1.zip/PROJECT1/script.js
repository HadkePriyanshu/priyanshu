let cartCount = 0;

// Add product to cart
function addToCart(product) {
  cartCount++;
  const cartCountElement = document.getElementById("cartCount");
  if (cartCountElement) {
    cartCountElement.textContent = cartCount;
  }
  alert(`${product} added to cart!`);
}

// Open product detail modal
function openModal(title, price, desc) {
  const modal = document.getElementById("productModal");
  if (modal) {
    document.getElementById("modalTitle").innerText = title;
    document.getElementById("modalPrice").innerText = "Price: " + price;
    document.getElementById("modalDesc").innerText = desc;
    modal.style.display = "block";
  }
}

// Close product detail modal
function closeModal() {
  const modal = document.getElementById("productModal");
  if (modal) {
    modal.style.display = "none";
  }
}




// Close modal or popup when clicking outside
window.onclick = function (event) {
  const productModal = document.getElementById("productModal");
  const loginPopup = document.getElementById("loginPopup");

  if (event.target === productModal) {
    closeModal();
  }

  if (event.target === loginPopup) {
    closeLogin();
  }
};

